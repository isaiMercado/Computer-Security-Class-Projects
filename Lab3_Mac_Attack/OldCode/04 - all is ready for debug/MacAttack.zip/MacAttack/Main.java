package MacAttack;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

	public static void main(String[] args) {
		
		
            try {
                // this is what we need for an length extension attack
                String text_initialMessage = "No one has completed lab 2 so give them all a 0";
                String hexString_initialMac = "f4b645e89faaec2ff8e443c595009c16dbdfba4b";
                String hashAlgorithm = "SHA-1"; // The algorithm is guessed by looking at the initalMac's length. In this case
                // the length is 20 bytes, and usually 20 bytes digests come from SHA-1
                String text_attackerMessage = "P.S. Except for Isai. He deserves 100% on all Projects";
                
                
                // Prepare variables for attack
//                byte[] initialMessage = HexUtility.TextToBytesArray(text_initialMessage);
//                byte[] initialMac = HexUtility.hexStringToByteArray(hexString_initialMac);
//                byte[] attackerMessage = HexUtility.TextToBytesArray(text_attackerMessage);
//                
//                // Attack
//                byte[] initialMessageWithPadding = SHA_1_Attacker.addPadding(initialMessage);
//                byte[] modifiedMessage = SHA_1_Attacker.appendAttackerText(initialMessageWithPadding, attackerMessage);
//                byte[] modifiedMac = SHA_1_Attacker.getModifiedMac(initialMac, modifiedMessage);
//                
//                // sha
//                Sha_1 sha = new Sha_1();
//                String hash = sha.hash(text_initialMessage);
//                System.out.println(" my hash 0x" + hash);
//                
//                MessageDigest sha_1 = MessageDigest.getInstance("SHA-1");
//                sha_1.reset();
//                sha_1.update(initialMessage); // text
//                byte[] hashSha = sha_1.digest(); // state
//                System.out.println("sha hash " + HexUtility.bytesArrayToHexString(hashSha));
                
        String hexString_modifiedMessage = Sha_1_Attacker.getHexStringModifiedMessage(text_initialMessage, text_attackerMessage); 
        String hexString_modifiedMac = Sha_1_Attacker.getHexStringModifiedMac(text_attackerMessage, hexString_initialMac);
        
        System.out.println("hexString modifiedMessage " + hexString_modifiedMessage);
        System.out.println("hexString modifiedMac " + hexString_modifiedMac);
        System.out.println("\n");        
                
                // Printing out results
//                System.out.println("hexString initialMessage " + HexUtility.bytesArrayToHexString(initialMessage));
//                System.out.println("hexString initialMessageWithPadding " + HexUtility.bytesArrayToHexString(initialMessageWithPadding));
//                System.out.println("hexString attackerMessage " + HexUtility.bytesArrayToHexString(attackerMessage));
//                System.out.println("hexString modifiedMessage " + HexUtility.bytesArrayToHexString(modifiedMessage));
//                
//                System.out.println("hexString initialMac " + HexUtility.bytesArrayToHexString(initialMac));
//                System.out.println("hexString modifiedMac " + HexUtility.bytesArrayToHexString(modifiedMac));
//                System.out.println("\n");
            } catch (Exception ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
		
	} 
}
