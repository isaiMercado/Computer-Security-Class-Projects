package MacAttack;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

	public static void main(String[] args) {
		
//        // this is what we need for a length extension attack
//        String text_initialMessage = "No one has completed lab 2 so give them all a 0"; // This was intercepted
//        String hexString_initialMac = "f4b645e89faaec2ff8e443c595009c16dbdfba4b"; // This was intercepted
//        
//        String hashAlgorithm = "SHA-1"; // The algorithm is guessed by looking at the initalMac's length. In this case the length is 20 bytes which usually come from SHA-1
//        int keyBitsLength = 128; // The key length was obtained by some other means
//        
//        String text_attackerMessage = "P.S. Except for Isai. He deserves 100% on all Projects"; // We make this extension text
//            
//        
//        
//        // preparing variables for attack
//        int initialMessageBitsLength = Sha_1_Attacker.getMessageBitsLengthWithoutPadding(text_initialMessage);
//        int initialMessageBitsLenghtWithPadding = Sha_1_Attacker.getMessageBitsLengthWithPadding(text_initialMessage);
//        int attackerMessageBitsLength = Sha_1_Attacker.getMessageBitsLengthWithoutPadding(text_attackerMessage);
//        int[] initialMac = HexUtility.hexStringToIntArray(hexString_initialMac);
//        
//        
//        
//        // attack
//        String hexString_modifiedMessage = Sha_1_Attacker.getHexStringModifiedMessage(text_initialMessage, keyBitsLength, initialMessageBitsLength, text_attackerMessage); 
//        String hexString_modifiedMac = Sha_1_Attacker.getHexStringModifiedMac(text_attackerMessage, keyBitsLength, initialMessageBitsLenghtWithPadding, attackerMessageBitsLength, initialMac);
//        
//        
//        
//        // print results
//        System.out.println("hexString modifiedMessage " + hexString_modifiedMessage);
//        System.out.println("hexString modifiedMac " + hexString_modifiedMac);
//        System.out.println("\n");  
//		
//        
//        
//        // tests to make sure functions work correctly
//        String test = "randomText......jijwidjwijdiwjdiwjdwdjppp";
//        int testBitsLength = Sha_1_Attacker.getMessageBitsLengthWithoutPadding(test); // get bits without padding works
//        Sha_1 sha1 = new Sha_1();
//        int[][] blocks = sha1.parseMessage(test, testBitsLength); // parse message works
//        String hexString_blocks = sha1.blocksToString(blocks); // blocks to string works
//        System.out.println("hexString_blocks " + hexString_blocks);
//        
//        
//        int testBitsLengthWithPadding = Sha_1_Attacker.getMessageBitsLengthWithPadding(test); // get bits with padding works
//        System.out.println("testBitsLengthWithPadding " + testBitsLengthWithPadding); 
//        
//        
//        String hexMac = sha1.hash(test, testBitsLength); // hashing works
//        System.out.println("hexMac " + hexMac);
//        System.out.println("\n"); 
        
        // sha1 secret foo
        String secret = "secret";
        String foo = "foo";
        String secretFoo = secret + foo;
        String theirSecretFooMac = "a5e702a34cc6d079645ff9634ac4b7c16ac41a68";
        
        Sha_1 sha_1 = new Sha_1();
        String mySecretFooMac = sha_1.hash(secretFoo, secretFoo.length() * 8);
        
        System.out.println("theirSecretFooMac " + theirSecretFooMac);
        System.out.println("mySecretFooMac    " + mySecretFooMac);
        System.out.println("\n");
        
        int[] macArray = HexUtility.hexStringToIntArray(mySecretFooMac);
        int fooWithPadding = Sha_1_Attacker.getMessageBitsLengthWithPadding(foo);
        String theirFooWithPadding = "666f6f80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000048"; // erase 6 zeros
        String bar = "bar";
     
        String theirFooModifiedMessage = "666f6f80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000048626172";
        String theirFooModifiedMac = "1acc2d421c1f1d209c919dfeef74ee94443b5afe";
        String myFooModifiedMessage = Sha_1_Attacker.getHexStringModifiedMessage(foo, secret.length() * 8, foo.length() * 8, bar); 
        String myFooModifiedMac = Sha_1_Attacker.getHexStringModifiedMac(bar, secret.length() * 8, theirFooWithPadding.length() * 8, bar.length() * 8, macArray); /// secret.length() * 8, theirFooWithPadding.length() * 8, bar.length() * 8, macArray
        												  
        System.out.println("theirFooModifiedMessage " + theirFooModifiedMessage.length());
        System.out.println("myFooModifiedMessage    " + myFooModifiedMessage.length());
        System.out.println("theirFooModifiedMac " + theirFooModifiedMac);
        System.out.println("myFooModifiedMac    " + myFooModifiedMac);
        System.out.println("\n"); 
	} 
}
