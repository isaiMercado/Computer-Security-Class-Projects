package MacAttack;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.ArrayList;

public class Sha_1_Attacker {
	
	
    static String getHexStringModifiedMessage(String text_initialMessage, int keyBitsLenght, int initialMessageBitsLength, String text_attackerMessage) {
        Sha_1 sha1 = new Sha_1();
        int length = keyBitsLenght + initialMessageBitsLength;
        int[][] blocks_initialMessage = sha1.parseMessage(text_initialMessage, length);
        
        String hexString_initialMessageWithPadding = sha1.blocksToString(blocks_initialMessage);
        String hexString_attackerMessage = HexUtility.textToHexString(text_attackerMessage);
        
        String hexString_joinedMessage = hexString_initialMessageWithPadding + hexString_attackerMessage;
        return hexString_joinedMessage;
    }


	public static String getHexStringModifiedMac(String text_attackerMessage, int keyBitsLenght, int initialMessageBitsLengthWithPadding, int attackerMessageBitsLenght, int[] initialMac) {
		Sha_1 sha1 = new Sha_1();
		int length = keyBitsLenght + initialMessageBitsLengthWithPadding + attackerMessageBitsLenght;
		String hexString_mac = sha1.hash(text_attackerMessage, length, initialMac);
		return hexString_mac;
	}

	
	public static int getMessageBitsLengthWithoutPadding(String message) {
		int bitsLenght = message.length() * Sha_1.BITS_PER_BYTE;
		return bitsLenght;
	}


	public static int getMessageBitsLengthWithPadding(String message) {
		Sha_1 sha1 = new Sha_1();
		int[][] blocks = sha1.parseMessage(message, 0);
		int bitsLenght = blocks.length * Sha_1.WORDS_PER_BLOCK * Sha_1.BITS_PER_WORD;
		return bitsLenght;
	}


}
