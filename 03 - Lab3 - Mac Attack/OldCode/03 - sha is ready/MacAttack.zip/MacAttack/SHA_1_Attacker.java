package MacAttack;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.ArrayList;

public class SHA_1_Attacker {

	public final static int BLOCK_TOTAL_BITS = 512;
	public final static int BLOCK_TOTAL_BYTES = 64;
	
	public final static int BLOCK_USABLE_BITS = 448;
	public final static int BLOCK_USABLE_BYTES = 56;
	
	public final static int REGISTER_MESSAGE_LENGTH_BITS = 64;
	public final static int REGISTER_MESSAGE_LENGTH_BYTES = 8;
	
	public final static int REGISTER_LENGTH_BYTES = 16;
	public final static int REGITERS_PER_BLOCK = 4;
	

	
	public static byte[] appendAttackerText(byte[] messageWithPadding, byte[] attackerMessage) {
	    int aLength = messageWithPadding.length;
	    int bLength = attackerMessage.length;
	    byte[] bytes = new byte[aLength + bLength];
	    System.arraycopy(messageWithPadding, 0, bytes, 0, aLength);
	    System.arraycopy(attackerMessage, 0, bytes, aLength, bLength);
	    return bytes;
	}

	
	public static byte[] addPadding(byte[] initialMessage) {
		ArrayList<byte[][]> blocks = parseText(initialMessage);
		byte[] messageWithPadding = parseBlocks(blocks);
		return messageWithPadding;	
	}
	
	
	private static byte[] parseBlocks(ArrayList<byte[][]> blocks) {
		int bytesLength = blocks.size() * blocks.get(0).length * blocks.get(0)[0].length;
		byte[] bytes = new byte[bytesLength];
		int byteIndex = 0;
		for (int listIndex = 0; listIndex < blocks.size(); listIndex++) {
			for (int rowIndex = 0; rowIndex < blocks.get(0).length; rowIndex++) {
				for (int colIndex = 0; colIndex < blocks.get(0)[0].length; colIndex++) {
					bytes[byteIndex] = blocks.get(listIndex)[rowIndex][colIndex];
					byteIndex++;
				}
			}
		}
		
		return bytes;
	}
	
	
	private static ArrayList<byte[][]> parseText(byte[] messageBytes) {
		ArrayList<byte[][]> initialBlocks = new ArrayList<byte[][]>();
		byte[] messageLength = parseLengthToBytes(messageBytes.length);
		int MAX_BLOCK_POSSIBLE = BLOCK_TOTAL_BYTES / messageBytes.length;
		
		int messageByteIndex = 0;
		for(int blockIndex = 0; blockIndex < MAX_BLOCK_POSSIBLE; blockIndex++) {
			byte[][] block = new byte[REGITERS_PER_BLOCK][REGISTER_LENGTH_BYTES];
			for (int registerIndex = 0; registerIndex < REGITERS_PER_BLOCK; registerIndex++) {
				for (int registerByteIndex = 0; registerByteIndex < REGISTER_LENGTH_BYTES; registerByteIndex++) {
					if (messageByteIndex == messageBytes.length) {
						block[registerIndex][registerByteIndex] = (byte)0x80; //47
					} else if (messageByteIndex > messageBytes.length) {
						if (blockIndex == MAX_BLOCK_POSSIBLE-1 && registerIndex == REGITERS_PER_BLOCK-1 && registerByteIndex == REGISTER_MESSAGE_LENGTH_BYTES-1) {
							block[registerIndex][REGISTER_MESSAGE_LENGTH_BYTES  ] = (byte)messageLength[0]; // 56
							block[registerIndex][REGISTER_MESSAGE_LENGTH_BYTES+1] = (byte)messageLength[1]; // 57
							block[registerIndex][REGISTER_MESSAGE_LENGTH_BYTES+2] = (byte)messageLength[2]; // 58
							block[registerIndex][REGISTER_MESSAGE_LENGTH_BYTES+3] = (byte)messageLength[3]; // 59
							block[registerIndex][REGISTER_MESSAGE_LENGTH_BYTES+4] = (byte)messageLength[4]; // 60
							block[registerIndex][REGISTER_MESSAGE_LENGTH_BYTES+5] = (byte)messageLength[5]; // 61
							block[registerIndex][REGISTER_MESSAGE_LENGTH_BYTES+6] = (byte)messageLength[6]; // 62
							block[registerIndex][REGISTER_MESSAGE_LENGTH_BYTES+7] = (byte)messageLength[7]; // 63
							registerByteIndex = REGISTER_LENGTH_BYTES;
						} else { // registers are 0, 1, and 2
							block[registerIndex][registerByteIndex] = (byte)0x00; // 48 - 55 
						}
					} else { // messageByteIndex < message.length
						block[registerIndex][registerByteIndex] = (byte)messageBytes[messageByteIndex]; // 1 - 46
					} 
					messageByteIndex++;
				}
			}
			initialBlocks.add(block);
		}
		return initialBlocks;
	}
	
	
	public static byte[] getModifiedMac(byte[] state, byte[] text) {
		byte[] modifiedMac = null;
		
		try {
		    MessageDigest sha_1 = MessageDigest.getInstance("SHA-1");
		    sha_1.reset();
		    sha_1.update(state); // text
		    modifiedMac = sha_1.digest(text); // state
		} catch (Exception ex) {
			System.err.println(ex);
		}
		
	    return modifiedMac;
	}
	
	
	private static byte[] parseLengthToBytes(int integer) {
		int BITS = 8;
		integer = integer * BITS;
		
	    byte[] result = new byte[8];

	    result[0] = 0;//(byte) (integer >> 56);
	    result[1] = 0;//(byte) (integer >> 48);
	    result[2] = 0;//(byte) (integer >> 40);
	    result[3] = 0;//(byte) (integer >> 32);
	    result[4] = (byte) (integer >> 24);
	    result[5] = (byte) (integer >> 16);
	    result[6] = (byte) (integer >> 8 );
	    result[7] = (byte) (integer >> 0 );
		  
		return result;
	}

    static String getHexStringModifiedMessage(String text_initialMessage, String text_attackerMessage) {
        Sha_1 sha1 = new Sha_1();
        int[][] blocks_initialMessage = sha1.parseMessage(text_initialMessage);
        int[][] blocks_attackerMessage = sha1.parseMessage(text_attackerMessage);
        int[][] blocks_joinedMessages = joinBlocksMessages(blocks_initialMessage, blocks_attackerMessage);
        String hexString_joinedMessages = blockToHexString(blocks_joinedMessages);
    }

    private static int[][] joinBlocksMessages(int[][] blocks_initialMessage, int[][] blocks_attackerMessage) {
        ArrayList<int[]> list = new ArrayList<int[]>();
        for (int i = 0; i < blocks_initialMessage.length; i++) {
            list.add(blocks_attackerMessage[i]);
        }
        for (int i = 0; i < blocks_initialMessage.length; i++) {
            list.add(blocks_attackerMessage[i]);
        }
        return (int[][])list.toArray();
    }

    private static String blockToHexString(int[][] blocks_joinedMessages) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < blocks_joinedMessages.length; i++) {
            
        }
    }
	
	
}
