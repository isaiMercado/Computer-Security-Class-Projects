/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cipher;

import Properties.AESByte;
import Properties.AESByte;
import Properties.AESState;
import Properties.AESState;
import Properties.AESTables;
import Properties.AESTables;
import Properties.AESWord;
import Properties.AESWord;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rental
 */
public class AESKeySchedule {
    
	private ArrayList<AESState> keyStates;
    private AESState currentState;
    private int RconIndex;
    private int nextKeyCounter;
    
     public AESKeySchedule(AESState initialState) {
         this.currentState = initialState;
         this.RconIndex = 1;
         this.nextKeyCounter = 0;
         this.keyStates = new ArrayList<AESState>();
         generateKeys();
     }
     
     private void generateKeys() {
    	 for (int i = 0; i < 11; i++) {
    		 this.keyStates.add(generateNextKey());
    	 }
     }
     
     
     public AESState getKeyState(int index) {
    	 return keyStates.get(index);
     }
     
     
     private AESState generateNextKey() {
         AESState nextState = new AESState();
         if (this.nextKeyCounter != 0) {
	         try {
	            AESWord RconColumn = new AESWord(new AESByte(AESTables.Rcon[RconIndex]), new AESByte(), new AESByte(), new AESByte());
	            this.RconIndex++;
	            
	            AESWord currentStatelastColumn = currentState.getColumn(3); 
	            //System.out.println("rotWord is " + currentStatelastColumn.bytesToString());
	            currentStatelastColumn = shiftContent(currentStatelastColumn);
	            //System.out.println("shifted rotWord is " + currentStatelastColumn.bytesToString());
	            currentStatelastColumn = switchSboxValue(currentStatelastColumn);
	            //System.out.println("subBytes rotWord is " + currentStatelastColumn.bytesToString());
	            AESWord currentStatefirstColumn = currentState.getColumn(0);
	            currentStatelastColumn = AESWord.xor(currentStatelastColumn, RconColumn);
	            currentStatelastColumn = AESWord.xor(currentStatelastColumn, currentStatefirstColumn);
	            //System.out.println("RconColumn is " + RconColumn.bytesToString());
	            //System.out.println("firstColumn is " + currentStatefirstColumn.bytesToString());
	            //System.out.println("xor rotWord is " + currentStatelastColumn.bytesToString());
	            
	            nextState.setColumn(0, currentStatelastColumn);
	            
	            for (int nextStateCol = 0; nextStateCol < 3; nextStateCol++) {
	                AESWord currentStateColumn = this.currentState.getColumn(nextStateCol + 1);
	                AESWord nextStateColumn = nextState.getColumn(nextStateCol);
	                AESWord xorResult = AESWord.xor(currentStateColumn, nextStateColumn);
	                //System.out.println("nextStateCol at index " + nextStateCol+1 + " is " + xorResult.bytesToString());
	                nextState.setColumn(nextStateCol+1, xorResult);
	            }
	            
	         } catch (Exception ex) {
	             Logger.getLogger(AESWord.class.getName()).log(Level.SEVERE, null, ex);
	         }
	         
	         this.currentState = nextState;
         } else {
        	 nextState = this.currentState;
         }
         
         //System.out.println("key schedule at index " + this.nextKeyCounter + nextState.bytesToString());
         this.nextKeyCounter++;
         return nextState;
     }

    private AESWord shiftContent(AESWord lastColumn) {
        AESByte temporal = new AESByte();
        int numberOfBytesInWord = 4;
        for (int index = 0; index <= numberOfBytesInWord; index++) {
            if (index == 0) {
                temporal = lastColumn.getBytes()[0];
            } else if (index == numberOfBytesInWord) {
                lastColumn.getBytes()[3] = temporal;
            } else {
                lastColumn.getBytes()[index - 1] = lastColumn.getBytes()[index];
            }
        }
        return lastColumn;
    }

    private AESWord switchSboxValue(AESWord lastColumn) {
        int maxNumberOfBytesInWord = 4;
        for (int i = 0; i < maxNumberOfBytesInWord; i++) {
            lastColumn.getBytes()[i] = AESTables.findSboxValue(lastColumn.getBytes()[i]);
        }
        return lastColumn;
    }

   
}
