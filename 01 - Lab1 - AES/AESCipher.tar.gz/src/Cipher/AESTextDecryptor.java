/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cipher;

import Properties.AESByte;
import Properties.AESState;
import Properties.AESTables;
import Properties.AESWord;

import java.util.ArrayList;

/**
 *
 * @author rental
 */
public class AESTextDecryptor {
    
    private ArrayList<AESState> states;
    private AESKeySchedule keySchedule;
    
    public AESTextDecryptor(ArrayList<AESState> states, AESKeySchedule keySchedule) {
        this.states = states;
        this.keySchedule = keySchedule;
    }
    
    public ArrayList<AESState> decrypt() {
        ArrayList<AESState> decryptedStates = new ArrayList<AESState>();
        for(int stateIndex = 0; stateIndex < this.states.size(); stateIndex++) {
            decryptedStates.add(decryptState(stateIndex));
        }
        return decryptedStates;
    }
    

    private AESState decryptState(int stateIndex) {
        
        AESState currentState = this.states.get(stateIndex);
        //System.out.println("current State is " + currentState.bytesToString());
        
        currentState = addRoundKey(currentState, this.keySchedule.getKeyState(10));
        //System.out.println("currentState after roundKey " + currentState.bytesToString());
        
        for (int i = 9; i >= 1; i--) {
            currentState = invShiftRows(currentState);
            //System.out.println("currentState after invShiftRows " + currentState.bytesToString());
            currentState = invSubBytes(currentState);
            //System.out.println("currentState after invSubBytes " + currentState.bytesToString());
            currentState = addRoundKey(currentState, this.keySchedule.getKeyState(i));
            //System.out.println("currentState after addRoundKey " + currentState.bytesToString());
            currentState = invMixColumns(currentState);
            //System.out.println("currentState after invMixColumns " + currentState.bytesToString());
        }
        
        currentState = invShiftRows(currentState);
        //System.out.println("currentState after last invShiftRows " + currentState.bytesToString());
        currentState = invSubBytes(currentState);
        //System.out.println("currentState after last invSubBytes " + currentState.bytesToString());
        currentState = addRoundKey(currentState, this.keySchedule.getKeyState(0));
        //System.out.println("currentState after last addRoundKey " + currentState.bytesToString());
        
        return currentState;
    }
    
    private AESState addRoundKey(AESState currentState, AESState currentKey) {
        return AESState.xor(currentState, currentKey);
    }

    private AESState invShiftRows(AESState currentState) {
        int matrixLength = 4;
        
        for (int row = 0; row < matrixLength; row++) {
            currentState = invShiftRow(currentState, row);
        }
        return currentState;
    }

    private AESState invShiftRow(AESState currentState, int row) {
        int matrixLength = 4;
        
        for (int time = 0; time < row; time++) {
            AESByte temporal = new AESByte();
            for (int square = matrixLength - 1; square >= -1 ; square--) {
                int rightSquare = square + 1;
                if (square == matrixLength - 1) {
                    temporal = currentState.getMatrix()[row][3];
                } else if (square == -1) { 
                    currentState.setValue(row, 0, temporal);
                } else {
                    currentState.setValue(row, rightSquare, currentState.getMatrix()[row][square]);
                }
            }
            
        }
        
        return currentState;
    }

    private AESState invSubBytes(AESState currentState) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                AESByte value = AESTables.findInvSboxValue(currentState.getMatrix()[i][j]);
                currentState.setValue(i, j, value);
            }
        }
        return currentState;
    }

    private AESState invMixColumns(AESState currentState) {
    	AESState mixMatrix = new AESState(AESTables.invMixColumns);
    	AESState output = new AESState();
    	//System.out.println("mixMatrix " + mixMatrix.bytesToString());
    	try {
			for (int colIndex = 0; colIndex < 4; colIndex++) {
				AESWord currentStateColumn = currentState.getColumn(colIndex);
				for (int rowIndex = 0; rowIndex < 4; rowIndex++) {
					AESWord mixMatrixRow = mixMatrix.getRow(rowIndex);
					//System.out.println("currentStateColumn " + currentStateColumn.bytesToString());
					//System.out.println("mixMatrixRow " + mixMatrixRow.bytesToString());
					AESByte resutTerm = AESWord.ffMultiply(currentStateColumn,mixMatrixRow);
					//System.out.println("resutTerm " + resutTerm.byteToString());
					output.setValue(rowIndex,colIndex,resutTerm); 
				}
			}
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	}
        return output; 
    }
}
