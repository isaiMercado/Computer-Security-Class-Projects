/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

import Cipher.AESCipher;
import Cipher.AESKeySchedule;
import Properties.AESByte;
import Properties.AESState;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rental
 */
public class Lab1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
        	// playgrounds
        	AESByte firstNumber = new AESByte((byte)0x57);
        	AESByte secondNumber = new AESByte((byte)0x13);
        	AESByte resultNumber = AESByte.multiply(firstNumber, secondNumber);
        	System.out.println("multiplication Result " + resultNumber.byteToString());
        	
        	// end Playgrounds
        	
//        	byte[][] keyExample = {
//        			{(byte)0x2b,(byte)0x28,(byte)0xab,(byte)0x09},
//        			{(byte)0x7e,(byte)0xae,(byte)0xf7,(byte)0xcf},
//        			{(byte)0x15,(byte)0xd2,(byte)0x15,(byte)0x4f},
//        			{(byte)0x16,(byte)0xa6,(byte)0x88,(byte)0x3c}
//        		};
//        	
//        	AESState keyExampleMatrix = new AESState(keyExample);
//        	
//        	System.out.println("keyExampleString - " + keyExampleMatrix.toString());
//        	System.out.println("keyExampleBytes " + keyExampleMatrix.bytesToString());
//        	
//        	byte[][] textExample = {
//        			{(byte)0x32,(byte)0x88,(byte)0x31,(byte)0xe0},
//        			{(byte)0x43,(byte)0x5a,(byte)0x31,(byte)0x37},
//        			{(byte)0xf6,(byte)0x30,(byte)0x98,(byte)0x07},
//        			{(byte)0xa8,(byte)0x8d,(byte)0xa2,(byte)0x34}
//        		};
        	
        	byte[][] keyExample = {
        			{(byte)0x00,(byte)0x04,(byte)0x08,(byte)0x0c},
        			{(byte)0x01,(byte)0x05,(byte)0x09,(byte)0x0d},
        			{(byte)0x02,(byte)0x06,(byte)0x0a,(byte)0x0e},
        			{(byte)0x03,(byte)0x07,(byte)0x0b,(byte)0x0f}
        		};
        	AESState keyExampleMatrix = new AESState(keyExample);
        	System.out.println("keyExampleString - " + keyExampleMatrix.toString());
        	System.out.println("keyExampleBytes " + keyExampleMatrix.bytesToString());
        	
        	
        	
        	byte[][] textExample = {
        			{(byte)0x00,(byte)0x44,(byte)0x88,(byte)0xcc},
        			{(byte)0x11,(byte)0x55,(byte)0x99,(byte)0xdd},
        			{(byte)0x22,(byte)0x66,(byte)0xaa,(byte)0xee},
        			{(byte)0x33,(byte)0x77,(byte)0xbb,(byte)0xff}
        		};
        	AESState textExampleMatrix = new AESState(textExample);
        	System.out.println("textExampleString - " + textExampleMatrix.toString());
        	System.out.println("textExampleBytes " + textExampleMatrix.bytesToString());
        	
        	
        	
        	ArrayList<AESState> textExampleStates = new ArrayList<AESState>();
        	textExampleStates.add(textExampleMatrix);
        	
        	AESKeySchedule keySchedule = new AESKeySchedule(new AESState(keyExample));
        	
        	
        	
            AESCipher cipher = new AESCipher(textExampleStates, keySchedule);
            
            ArrayList<AESState> textExampleStatesEncrypted = cipher.encrypt();
            
            AESState cipherState = textExampleStatesEncrypted.get(0);
            System.out.println("cipher State is " + cipherState.bytesToString());
            
            String cipherText = AESState.printStates(textExampleStatesEncrypted);
            System.out.println("cipherText - " + cipherText);
            
            
            cipher = new AESCipher(textExampleStatesEncrypted, keySchedule);
            ArrayList<AESState> textExampleStatesDecrypted = cipher.decrypt();
            
            AESState decipherState = textExampleStatesDecrypted.get(0);
            System.out.println("decipher State is " + decipherState.bytesToString());
            
            String decipherText = AESState.printStates(textExampleStatesDecrypted);
            System.out.println("decipherText - " + decipherText);
            
            int isai = 0;
        	
//        	String text = "00112233445566778899aabbccddeeff";
//        	String key = "000102030405060708090a0b0c0d0e0f";
//        	
//        	AESCipher cipher = new AESCipher(text, key);
//        	ArrayList<AESState> encryption = cipher.encrypt();
//        	
//            AESState cipherState = encryption.get(0);
//            System.out.println("cipher State is " + cipherState.bytesToString());
//          
//            String cipherText = AESState.printStates(encryption);
//            System.out.println("cipherText - " + cipherText);
        	
        } catch (Exception ex) {
            Logger.getLogger(Lab1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
