/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Properties;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 *
 * @author rental
 */
public class AESState {
    
    public static String printStates(ArrayList<AESState> states) {
        String output = new String();
        for (int i = 0 ; i < states.size(); i++) {
            output = output + states.get(i).toString();
        }
        return output;
    }
    
    public static AESState multiply(AESState firstMatrix, AESState seconMatrix) {
        int matrixLength = 4;
        
        AESState result = new AESState();
        AESByte sum = new AESByte();
        for (int i = 0 ; i < matrixLength ; i++) {
            for (int j = 0 ; j < matrixLength; j++) {
                for (int k = 0 ; k < matrixLength; k++) {
                	AESByte leftTerm = firstMatrix.getMatrix()[i][k];
                	AESByte rightTerm = seconMatrix.getMatrix()[k][j];
                	AESByte resultTerm = AESByte.multiply(leftTerm, rightTerm);
                	//System.out.println("multiplication leftTerm " + leftTerm.byteToString());
                	//System.out.println("multiplication rightTerm " + rightTerm.byteToString());
                	//System.out.println("multiplication result " + resultTerm.byteToString());
                    sum = AESByte.sum(sum, resultTerm);
                    //System.out.println("sum result " + sum.byteToString());
                }
                //System.out.println("\n");
                //System.out.println("sum total " + sum.byteToString());
                result.setValue(i, j, sum);
                sum = new AESByte();
            }
        }
        return result;
    }
    
    public static AESState xor (AESState firstState, AESState secondState) {
        AESState outputState = new AESState();
        
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                AESByte result = AESByte.xor(firstState.getMatrix()[i][j], secondState.getMatrix()[i][j]);
                outputState.setValue(i, j, result);
            }
        }
        return outputState;
    }
        
    private final int MATRIX_LENGTH = 4;
    private AESByte[][] matrix = new AESByte[4][4];
    
    public AESState() {
        for (int i = 0; i < this.MATRIX_LENGTH; i++) {
            for (int j = 0; j < this.MATRIX_LENGTH; j++) {
                matrix[i][j] = new AESByte();
            }
        }
    }
    
    public AESState(byte[][] bytes) {
        for (int i = 0; i < this.MATRIX_LENGTH; i++) {
            for (int j = 0; j < this.MATRIX_LENGTH; j++) {
            	AESByte aByte = new AESByte(bytes[i][j]);
                matrix[i][j] = aByte;
                
                //System.out.println("byte to state - " + aByte.byteToString());
            }
        }
    }
    
    public AESState(AESByte[] bytes) throws Exception {
        if (bytes.length == 16) {
            int index = 0;
            for (int col = 0; col < this.MATRIX_LENGTH; col++) {
                for (int row = 0; row < this.MATRIX_LENGTH; row++) {
                    matrix[row][col] = bytes[index];
                    index++;
                }
            }
        } else {
            throw new Exception("bytes too long for state");
        }
    }
    
    public AESState(AESWord[] words) throws Exception {
        if (words.length == 4) {
            for (int col = 0; col < this.MATRIX_LENGTH; col++) {
                for (int row = 0; row < this.MATRIX_LENGTH; row++) {
                    matrix[row][col] = words[col].getBytes()[row];
                }
            }
        } else {
            throw new Exception("words too long for state");
        }
    }
    
    public AESState(AESWord word0, AESWord word1, AESWord word2, AESWord word3) {
        ArrayList<AESWord> words = new ArrayList<AESWord>();
        words.add(word0);
        words.add(word1);
        words.add(word2);
        words.add(word3);
        for (int col = 0; col < words.size(); col++) {
            for (int row = 0; row < words.size(); row++) {
                matrix[row][col] = words.get(col).getBytes()[row];
            }
        }
    }
        
    public AESState(AESState state) throws Exception {
        for (int col = 0; col < this.MATRIX_LENGTH; col++) {
            for (int row = 0; row < this.MATRIX_LENGTH; row++) {
                matrix[row][col] = state.getMatrix()[col][row];
            }
        }
    }
    
    public AESState(AESByte[][] bytes) {
        this.matrix = bytes;
    }

    /**
     * @return the matrix
     */
    public AESByte[][] getMatrix() {
        return matrix;
    }

    /**
     * @param matrix the matrix to set
     */
    public void setMatrix(AESByte[][] matrix) {
        this.matrix = matrix;
    }
    
    public void setValue(int row, int col, AESByte value) {
        this.matrix[row][col] = value;
    }

    public AESWord getColumn(int colIndex) throws Exception {
        AESWord column = new AESWord();
        if (colIndex >= 0 && colIndex < 4) {
            for (int row = 0; row < 4; row++) {
                column.getBytes()[row] = this.matrix[row][colIndex];
            }
            return column;
        } else {
            throw new Exception("index of column out of Bounds");
        }
    }
    
    public AESWord getRow(int rowIndex) {
    	AESWord output = new AESWord();
    	try {
	    	byte[] byteRow = new byte[4];
	        for (int col = 0; col < 4; col++) {
	        	byteRow[col] = this.matrix[rowIndex][col].getByte();
	        }
	        output = new AESWord(byteRow);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return output;
    }
    
    public void setColumn(int col, AESWord colValues) throws Exception {
        if (col >= 0 && col < 4) {
            for (int row = 0; row < 4; row++) {
                this.matrix[row][col] = colValues.getBytes()[row];
            }
        } else {
            throw new Exception("index of column out of Bounds");
        }
    }
    
    @Override
    public String toString() {
        byte[] bytes = new byte[16]; 
        
        int counter = 0;
        for (int col = 0; col < 4; col++) {
            for(int row = 0; row < 4; row++) {
                bytes[counter] = this.matrix[col][row].getByte();
                counter++;
            }
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }
    
    public String bytesToString() {
        byte[] bytes = new byte[16]; 
        
        int counter = 0;
        for (int row = 0; row < 4; row++) {
            for(int col = 0; col < 4; col++) {
                bytes[counter] = this.matrix[row][col].getByte();
                counter++;
            }
        }
        
	    StringBuilder stringBuilder = new StringBuilder();
	    stringBuilder.append("\n");
	    
	    for (int i = 1 ; i <= bytes.length; i++) {
	    	byte aByte = bytes[i-1];
	    	stringBuilder.append(String.format("%02X ", aByte));
	    	if ((i % 4) == 0 && i != 0) {
	    		stringBuilder.append("\n");
	    	}
	    }
	    
	    stringBuilder.append("\n");
	    
	    return stringBuilder.toString();
    }
}
