package AES;

public class AES_Main {

	public static void main(String[] args) {
		String textToEncrypt = "00112233445566778899aabbccddeeff";
		
		String key128 = "000102030405060708090a0b0c0d0e0f";
		String key192 = "000102030405060708090a0b0c0d0e0f1011121314151617";
		String key256 = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f";
		
		Cipher cipher = new Cipher();
		String textEncrypted = cipher.Encryption(textToEncrypt, key256);
		System.out.println("textEncrypted" + textEncrypted + "\n");
		
		InverseCipher inverseCipher = new InverseCipher();
		String textDecrypted = inverseCipher.Decryption(textEncrypted, key256);
		System.out.println("textDecrypted" + textDecrypted + "\n");
	} 
}
