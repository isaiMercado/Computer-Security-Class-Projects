package MacAttack;

public class HexUtility {

	
	public static byte[] TextToBytesArray(String input) {
		return input.getBytes();
	}
	
	
	public static String bytesArrayToText(byte[] bytes) {
		return new String(bytes);
	}
	
	
	public static String bytesArrayToHexString(byte[] inputArray) {
		StringBuilder stringBuilder = new StringBuilder();
		for (int index = 0; index < inputArray.length; index++) {
			String stringByte = byteToStringRepresentation(inputArray[index]);
			stringBuilder.append(stringByte);
		}
		String output = "0x" + stringBuilder.toString().toUpperCase();
		return output;
	}
	
	
	public static byte[] hexStringToByteArray(String s) {
	    int len = s.length();
	    byte[] data = new byte[len / 2];
	    for (int i = 0; i < len; i += 2) {
	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
	                             + Character.digit(s.charAt(i+1), 16));
	    }
	    return data;
	}
	
	
	// Private Functions
	private static String byteToStringRepresentation(byte inputByte){
		String output = "";
		
		int unsignedNumber = (inputByte + 256) % 256;
		if((inputByte >= 0) && (inputByte < 16)) {
			output = output + "0";
		}
		
		output = output + Integer.toString(unsignedNumber,16);
		return output;
	}
	
	

}
