package MacAttack;

import java.util.ArrayList;

public class Sha_1 {
        
    public static final int BITS_PER_WORD = 32; 
    public static final int BYTES_PER_WORD = 4;
    
    public static final int WORDS_PER_BLOCK = 16;
    public static final int MESSAGE_SCHEDULE_CAPACITY = 80;
    
    
    public String hash(String message) {
        // convert string to UTF-8, as SHA only deals with byte-streams
        //byte[] msg = null;//msg.utf8Encode();

        // constants [§4.2.1]
        int[] K_Constants = { 0x5a827999, 0x6ed9eba1, 0x8f1bbcdc, 0xca62c1d6 };

        // PREPROCESSING

        //msg += String.fromCharCode(0x80);  // add trailing '1' bit (+ 0's padding) to string [§5.1.1]
        // add padding

        // convert string msg into 512-bit/16-integer blocks arrays of ints [§5.2.1]
        //var l = msg.length/4 + 2; // length (in 32-bit integers) of msg + ‘1’ + appended length
        //var N = Math.ceil(l/16);  // number of 16-integer-blocks required to hold 'l' ints
        //var M = new Array(N);

        int messageBytesLength = message.length();
        int l_messageWordsLength = messageBytesLength / BYTES_PER_WORD + 2;
        int N_numberOfBlocks = (int)Math.ceil((double)l_messageWordsLength/(double)WORDS_PER_BLOCK);
        int[][] M_Blocks = new int[N_numberOfBlocks][WORDS_PER_BLOCK];  

        for (int i_blockIndex = 0; i_blockIndex < N_numberOfBlocks; i_blockIndex++) {
            for (int t_wordIndex = 0; t_wordIndex < WORDS_PER_BLOCK; t_wordIndex++) { 
                M_Blocks[i_blockIndex][t_wordIndex] = getMessageWord(message, i_blockIndex, t_wordIndex);
            } // note running off the end of msg is ok 'cos bitwise ops on NaN return 0
        }

        int bitsPerByte = 8;
        M_Blocks[N_numberOfBlocks - 1][WORDS_PER_BLOCK - 2] = 0; 
        M_Blocks[N_numberOfBlocks - 1][WORDS_PER_BLOCK - 1] = messageBytesLength * 8;

        // set initial hash value [§5.3.1]
        int H0_previousHash = 0x67452301; // ints are always 32 bits
        int H1_previousHash = 0xefcdab89;
        int H2_previousHash = 0x98badcfe;
        int H3_previousHash = 0x10325476;
        int H4_previousHash = 0xc3d2e1f0;

        // HASH COMPUTATION [§6.1.2]

        int[] W_messageSchedule = new int[80]; 
        int a_currentHash, b_currentHash, c_currentHash, d_currentHash, e_currentHash;
        for (int i_blockIndex = 0; i_blockIndex < N_numberOfBlocks; i_blockIndex++) {

            // 1 - prepare message schedule 'W'
            for (int t_wordIndex = 0; t_wordIndex < WORDS_PER_BLOCK; t_wordIndex++) { 
                    W_messageSchedule[t_wordIndex] = M_Blocks[i_blockIndex][t_wordIndex];
            }
            for (int t_wordIndex = WORDS_PER_BLOCK; t_wordIndex < MESSAGE_SCHEDULE_CAPACITY; t_wordIndex++) {
                    W_messageSchedule[t_wordIndex] = ROTL(W_messageSchedule[t_wordIndex-3] ^ W_messageSchedule[t_wordIndex-8] ^ W_messageSchedule[t_wordIndex-14] ^ W_messageSchedule[t_wordIndex-16], 1);
            }

            // 2 - initialise five working variables a, b, c, d, e with previous hash value
            a_currentHash = H0_previousHash; 
            b_currentHash = H1_previousHash; 
            c_currentHash = H2_previousHash; 
            d_currentHash = H3_previousHash; 
            e_currentHash = H4_previousHash;

            // 3 - main loop
            for (int t_wordIndex = 0; t_wordIndex < MESSAGE_SCHEDULE_CAPACITY; t_wordIndex++) {
                int s_operationIndex = (int)Math.floor(t_wordIndex/20); // seq for blocks of 'f' functions and 'K' constants
                int T_temporaryHash = (ROTL(a_currentHash,5) + f(s_operationIndex,b_currentHash,c_currentHash,d_currentHash) + e_currentHash + K_Constants[s_operationIndex] + W_messageSchedule[t_wordIndex]) & 0xffffffff;
                e_currentHash = d_currentHash;
                d_currentHash = c_currentHash;
                c_currentHash = ROTL(b_currentHash, 30);
                b_currentHash = a_currentHash;
                a_currentHash = T_temporaryHash;
            }

            // 4 - compute the new intermediate hash value (note 'addition modulo 2^32')
            H0_previousHash = (H0_previousHash + a_currentHash) & 0xffffffff;
            H1_previousHash = (H1_previousHash + b_currentHash) & 0xffffffff;
            H2_previousHash = (H2_previousHash + c_currentHash) & 0xffffffff;
            H3_previousHash = (H3_previousHash + d_currentHash) & 0xffffffff;
            H4_previousHash = (H4_previousHash + e_currentHash) & 0xffffffff;
        }

        return toHexStr(H0_previousHash) + toHexStr(H1_previousHash) + toHexStr(H2_previousHash) + toHexStr(H3_previousHash) + toHexStr(H4_previousHash);
    }


    public int f(int s, int x, int y, int z) {
        switch (s) {
            case 0: return (x & y) ^ (~x & z);           // Ch()
            case 1: return  x ^ y  ^  z;                 // Parity()
            case 2: return (x & y) ^ (x & z) ^ (y & z);  // Maj()
            case 3: return  x ^ y  ^  z;                 // Parity()
        }
        return 0;
    };


    public int ROTL(int x, int n) {
        return (x<<n) | (x>>>(32-n));
    };


    public String toHexStr(int n) {
    // note can't use toString(16) as it is implementation-dependant,
    // and in IE returns signed numbers when used on full words
    String hexString = Integer.toHexString(n);
    return hexString;
}

    
    private int getMessageWord(String message, int i_blockIndex, int t_wordIndex) {
        int nextBlock = BYTES_PER_WORD * WORDS_PER_BLOCK;
        int nextWord = BYTES_PER_WORD;
        int messageIndex = i_blockIndex * nextBlock + t_wordIndex * nextWord;
        int finalWord = 0;
        
        int[] wordChunks = new int[BYTES_PER_WORD];
        int shiftMultiple = BYTES_PER_WORD - 1;
        for (int byteIndex = 0; byteIndex < BYTES_PER_WORD; byteIndex++, shiftMultiple--) {
            if (messageIndex + byteIndex < message.length()) {
                int wordChunk = message.charAt(messageIndex + byteIndex) << (8 * shiftMultiple);
                wordChunks[byteIndex] = wordChunk;
            } else if (messageIndex + byteIndex == message.length()) {
                int wordChunk = 0x80 << (8 * shiftMultiple);
                wordChunks[byteIndex] = wordChunk;
            } else {
                int wordChunk = 0;
                wordChunks[byteIndex] = wordChunk;
            }
        }
        
        finalWord = wordChunks[0] | wordChunks[1] | wordChunks[2] | wordChunks[3];
        return finalWord;
    }

    
}
